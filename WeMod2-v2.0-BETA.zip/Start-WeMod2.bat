@echo off
start "" "%~dp0WeMod2.exe"
