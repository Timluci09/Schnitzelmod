@echo off
title WeMod 2.0 Launcher
cd /d "%~dp0"
powershell -Command "Unblock-File -Path '%~dp0WeMod2.exe' -ErrorAction SilentlyContinue"
start "" "%~dp0WeMod2.exe"
