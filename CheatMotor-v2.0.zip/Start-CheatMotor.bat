@echo off
title Cheat Motor Launcher
cd /d "%~dp0"
powershell -Command "Unblock-File -Path '%~dp0CheatMotor.exe' -ErrorAction SilentlyContinue; Unblock-File -Path '%~dp0WeMod2.exe' -ErrorAction SilentlyContinue"
if exist "%~dp0CheatMotor.exe" (
    start "" "%~dp0CheatMotor.exe"
) else (
    start "" "%~dp0WeMod2.exe"
)
