# ⚡ WeMod 2.0 - Standalone Game Trainer Studio (.exe)

Eine native Windows-Trainer-Anwendung im **WeMod-Design** mit Dark Gamer UI, Hardware-Beschleunigung, Windows-Memory-Engine, globalen Hotkeys, Sound-Effekten, integriertem Memory-Scanner und interaktiver Sandbox-Testumgebung.

# WeMod 2.0 [BETA] • Standalone Spiele-Trainer Studio

Eine eigenständige, moderne Trainer-Suite für PC-Spiele im edlen WeMod-Stil. Keine Drittanbieter-Bibliotheken, keine Installation erforderlich – kompiliert zu einer schlanken, nativen `WeMod2.exe`.

---

## ⚡ Aktueller Status: BETA-VERSION (Spiele-Trainer)

In dieser **BETA-Version** ist der **Spiele-Trainer für Minecraft 1.20.1** aktiv.

### 🟢 Aktive Beta-Features:
- **Flug-Modus (Speicher-Lock)** (`F1`): Schaltet echtes Fliegen (Doppelklick-Leertaste wie im Kreativmodus) direkt im Arbeitsspeicher (RAM) der Java Virtual Machine frei. Kein Chat wird geöffnet, keine Tastatur-Makros, keine Server-/Chat-Berechtigungen nötig.
- **Voll-Licht / Nachtsicht (FullBright)** (`F4`): Setzt das Gamma in den Spieleinstellungen auf 100.0 – sorgt für taghelle Ausleuchtung in Höhlen, Ozeanen und bei Nacht ohne Fackeln oder Tränke.
- **Auto-Fisher / Angel-Bot** (`F5`): Vollautomatisches Einholen & Wiederauswerfen im Hintergrund. Fische Schätze, verzauberte Bücher und Nahrungsmittel komplett AFK.
- **GitHub Auto-Update-Prüfer** (`🔄 Updates` in der Kopfleiste): Prüft per Knopfdruck oder im Hintergrund direkt auf `https://github.com/Timluci09/Schnitzelmod`, ob neue Versionen oder Fixes verfügbar sind, und bietet einen direkten 1-Klick-Download an!

### ⏳ Coming Soon (In Kürze verfügbar):
- **Gott-Modus / Unverwundbarkeit** (`F6`)
- **Kein Fallschaden (No Fall Damage)** (`F7`)
- **Flug- & Geh-Tempo Multiplikator** (`F8` / Schieberegler)
- **Raketen-Jetpack (Space-Boost)** (`F9`)
- **Stufen-Steigen (Step-Assist)** (`F10`)
- **Auto-Klicker (Schnellangriff)** (`F11`)
- **Schnell-Platzieren (Speed-Bridge)** (`F12`)
- **Sofort-Abbau (Instabuild)** (`NUM 1`)
- **Items behalten (KeepInventory)** (`NUM 5`)

---

## 🕹️ Integrierte Sandbox ("Target Dummy") zum sofortigen Testen

Falls du Minecraft gerade nicht geöffnet hast, kannst du alle Funktionen **sofort live** ausprobieren:
1. Klicke in der Seitenleiste auf **`🕹️ Sandbox Dummy`**.
2. Sieh dir den Live-Lebensbalken (100 HP), die Munition (30) und das Gold an.
3. Klicke auf **`💥 Take 25 Damage`** -> die HP sinken auf 75, 50, 25.
4. Schalte im Trainer oder per Taste `NUM 2` den Cheat **Freeze Health (100 HP)** ein:
   - Die HP schnappen sofort auf 100 zurück und bleiben dauerhaft eingefroren!
5. Klicke auf **`🔫 Shoot Bullet`** und schalte `NUM 3` (Infinite Ammo) ein:
   - Munition bleibt fest bei 30 Schuss!
6. Drücke `NUM 4`, um sofort **+$10.000 Gold** in den Speicher zu schreiben.

---

## 🔍 Cheat Engine Memory Scanner

Wie bei Cheat Engine kannst du jeden laufenden Windows-Prozess nach Speicherwerten durchsuchen:
1. Wähle **`🔍 Memory Scanner`** in der linken Leiste.
2. Gib den aktuellen Wert deines Spiels ein (z. B. dein aktuelles Gold: `500`).
3. Klicke auf **`First Scan`**.
4. Ändere den Wert im Spiel (z. B. durch Kaufen auf `450`).
5. Gib `450` ein und klicke auf **`Next Scan`**.
6. Klicke bei der gefundenen Adresse auf **`Lock / Edit`**, um den Wert auf `999.999` zu setzen und einzufrieren!

---

## 🎯 Process Browser

Unter **`🎯 Process Browser`** kannst du eine Live-Liste aller laufenden Windows-Prozesse einsehen, filtern und dich mit einem Klick auf **`Attach`** an jeden beliebigen Prozess hängen.

---

## ⌨️ Tastenbelegung frei anpassen (Hotkey Rebinding)

Du kannst jede Taste frei ändern:
1. Klicke einfach auf das Hotkey-Kästchen neben einem Cheat (z. B. `[ F1 ]`).
2. Das Feld wechselt auf lila: `[ PRESS KEY ]`.
3. Drücke eine beliebige Taste auf deiner Tastatur – die neue Taste wird sofort gespeichert!

---

## 🎵 WeMod Sound Chimes

Die Anwendung verfügt über einen integrierten Waveform-Synthesizer:
- **Einschalten**: Aufsteigender WeMod-Chime-Ton.
- **Ausschalten**: Absteigender WeMod-Chime-Ton.
- Kann in den **`⚙️ Settings`** ein- und ausgeschaltet werden.

---

## 🛠️ Neu kompilieren

Wenn du Änderungen am C#-Quellcode vornimmst, kannst du die `.exe` jederzeit neu bauen:
```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```
Erzeugt die optimierte, eigenständige `WeMod2.exe` direkt mit dem Windows-internen C#-Compiler.
